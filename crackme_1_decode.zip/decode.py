
from pwn import *

data = ""

with open("./crack_me1.exe","rb") as f:
		data = f.read()

func1_start = len(data.split("\x74\xaa\xcd\x70\xaa")[0])
func1_end = func1_start + 0x61
func1 = list(data[func1_start:func1_end])

with open("./func1_decoded","wb") as f:
	write_data = ""
	for i in func1:
		write_data += chr(ord(i) ^ 0x21)
	f.write(disasm(write_data,arch='i386'))
	with open("./func1_bin","wb") as f1:
		f1.write(write_data)


func2_start = len(data.split("\x77\xa9\xce\xa1\xce\x2e\xe5")[0])
func2_end = func2_start + 0x8e
func2 = list(data[func2_start:func2_end])

with open("./func2_decoded","wb") as f:
	write_data = ""
	for i in func2:
		write_data += chr(ord(i) ^ 0x22)
	f.write(disasm(write_data,arch='i386'))
	with open("./func2_bin","wb") as f1:
		f1.write(write_data)
	

func3_start = len(data.split("\x76\xa8\xcf\xa0\xcf\x47")[0])
func3_end = func3_start + 0x695
func3 = list(data[func3_start:func3_end])

with open("./func3_decoded","wb") as f:
	write_data = ""
	for i in func3:
		write_data += chr(ord(i) ^ 0x23)
	f.write(disasm(write_data,arch='i386'))
	with open("./func3_bin","wb") as f1:
		f1.write(write_data)
	


func4_start = len(data.split("\x71\xaf\xc8\xa5\xc8\x38\x25")[0])
func4_end = func4_start + 0xeb
func4 = list(data[func4_start:func4_end])

with open("./func4_decoded","wb") as f:
	write_data = ""
	for i in func4:
		write_data += chr(ord(i) ^ 0x24)
	f.write(disasm(write_data,arch='i386'))
	with open("./func4_bin","wb") as f1:
		f1.write(write_data)
	
func5_start = len(data.split("\x70\xae\xc9\xa6\xc9\x05")[0])
func5_end = func5_start + 0xdd
func5 = list(data[func5_start:func5_end])

with open("./func5_decoded","wb") as f:
	write_data = ""
	for i in func5:
		write_data += chr(ord(i) ^ 0x25)
	f.write(disasm(write_data,arch='i386'))
	with open("./func5_bin","wb") as f1:
		f1.write(write_data)
	
func6_start = len(data.split("\x73\xad\xca\xa5\xca\x02")[0])
func6_end = func6_start + 0x116
func6 = list(data[func6_start:func6_end])

with open("./func6_decoded","wb") as f:
	write_data = ""
	for i in func6:
		write_data += chr(ord(i) ^ 0x26)
	f.write(disasm(write_data,arch='i386'))
	with open("./func6_bin","wb") as f1:
		f1.write(write_data)



'''
func1 (buf,char_check){
	//may be is check byte
	if buf % 2 == 0:
		return 1 <=> buf ^ 0x20 == char_check
	else:
		return 1 <=> buf ^ 0x52 == char_check
}


func2 (buf,char_check){
	//may be is check word 
	var1 = (buf[0] << 8) | buf[1]
	c = 1
	while(c < 6){
		var1 = ((var1 << c) | (var1 >> (0x10-c)) ^ 0x1693
		c++;
	}

	return 1 <=>{
		char_check = var1
	}

func3(input[0:3],check[0:3]){
	//compare 3 times
	A[100->41] -> had data
	compare one by one
	buf[0]{
		var1 = (input[0] & 0xfc) >> 2
		compare(A[var1],check[0])
	}	
	buf[1]{
		var1 = (input[0] & 0x3) << 4 + (input[1] & 0xf0) >> 4
		compare(A[var1],check[1])
	}	
	buf[2]{
		var1 = (input[2] & 0xc0) >> 6 + (input[1] & 0xf)*4
		compare(A[var1],check[2])
	}	
	buf[2]{
		var1 = (input[2] & 0x3f)
		compare(A[var1],check[3])
	}	

}


func4 (){
	//compare 4 times
	buf[0x100] = {0};
	func5("susan",buf[0x100]) 
	func6(buf,input[0:4],int_check){
		//compare 4 times one by one
		var1 = 0
		var2 = 0
		c = 0
		while(true){
			var1 += 1;
			if(var1 > 0xff) var1 = 0;
			var2 = buf[var1] + var2;
			if(var2 > 0xff) var2 = 0;
			swap(buf[var1],buf[var2])
			compare(int_check[c],xor(input[c],buf[(buf[var1] + buf[var2]) & 0xff]))
			c++;
		} 

	}

}


}

uint UndefinedFunction_00000000(byte *param_1,byte *param_2)

{
  byte *pbVar1;
  int iVar2;
  char acStack104 [4];
  undefined uStack100;
  undefined uStack99;
  undefined uStack98;
  undefined uStack97;
  undefined uStack96;
  undefined uStack95;
  undefined uStack94;
  undefined uStack93;
  undefined uStack92;
  undefined uStack91;
  undefined uStack90;
  undefined uStack89;
  undefined uStack88;
  undefined uStack87;
  undefined uStack86;
  undefined uStack85;
  undefined uStack84;
  undefined uStack83;
  undefined uStack82;
  undefined uStack81;
  undefined uStack80;
  undefined uStack79;
  undefined uStack78;
  undefined uStack77;
  undefined uStack76;
  undefined uStack75;
  undefined uStack74;
  undefined uStack73;
  undefined uStack72;
  undefined uStack71;
  undefined uStack70;
  undefined uStack69;
  undefined uStack68;
  undefined uStack67;
  undefined uStack66;
  undefined uStack65;
  undefined uStack64;
  undefined uStack63;
  undefined uStack62;
  undefined uStack61;
  undefined uStack60;
  undefined uStack59;
  undefined uStack58;
  undefined uStack57;
  undefined uStack56;
  undefined uStack55;
  undefined uStack54;
  undefined uStack53;
  undefined uStack52;
  undefined uStack51;
  undefined uStack50;
  undefined uStack49;
  undefined uStack48;
  undefined uStack47;
  undefined uStack46;
  undefined uStack45;
  undefined uStack44;
  undefined uStack43;
  undefined uStack42;
  undefined uStack41;
  undefined4 uStack36;
  undefined4 uStack32;
  int iStack28;
  int iStack24;
  byte *pbStack20;
  byte *pbStack16;
  undefined uStack12;
  byte bStack11;
  byte bStack10;
  byte bStack9;
  byte abStack8 [4];
  
  pbStack16 = (byte *)0x0;
  pbStack20 = (byte *)0x0;
  iStack24 = 3;
  uStack32 = 0;
  uStack36 = 0;
  acStack104[0] = 'A';
  acStack104[1] = 0x42;
  acStack104[2] = 0x44;
  acStack104[3] = 0x43;
  uStack100 = 0x45;
  uStack99 = 0x48;
  uStack98 = 0x47;
  uStack97 = 0x46;
  uStack96 = 0x49;
  uStack95 = 0x4a;
  uStack94 = 0x4b;
  uStack93 = 0x4c;
  uStack92 = 0x55;
  uStack91 = 0x4e;
  uStack90 = 0x4f;
  uStack89 = 0x50;
  uStack88 = 0x59;
  uStack87 = 0x52;
  uStack86 = 0x54;
  uStack85 = 0x53;
  uStack84 = 0x4d;
  uStack83 = 0x56;
  uStack82 = 0x57;
  uStack81 = 0x58;
  uStack80 = 0x51;
  uStack79 = 0x5a;
  uStack78 = 0x61;
  uStack77 = 0x6a;
  uStack76 = 99;
  uStack75 = 100;
  uStack74 = 0x65;
  uStack73 = 0x66;
  uStack72 = 0x6f;
  uStack71 = 0x68;
  uStack70 = 0x69;
  uStack69 = 0x62;
  uStack68 = 0x6b;
  uStack67 = 0x6d;
  uStack66 = 0x6c;
  uStack65 = 0x6e;
  uStack64 = 0x67;
  uStack63 = 0x70;
  uStack62 = 0x71;
  uStack61 = 0x72;
  uStack60 = 0x73;
  uStack59 = 0x74;
  uStack58 = 0x75;
  uStack57 = 0x76;
  uStack56 = 0x34;
  uStack55 = 0x78;
  uStack54 = 0x7a;
  uStack53 = 0x79;
  uStack52 = 0x38;
  uStack51 = 0x31;
  uStack50 = 0x32;
  uStack49 = 0x33;
  uStack48 = 0x77;
  uStack47 = 0x35;
  uStack46 = 0x36;
  uStack45 = 0x37;
  uStack44 = 0x30;
  uStack43 = 0x39;
  uStack42 = 0x2b;
  uStack41 = 0x30;
  pbVar1 = (byte *)0x0;
  while( true ) {
    do {
      iVar2 = iStack24;
      iStack28 = iStack24;
      iStack24 = iStack24 + -1;
      if (iVar2 == 0) {
        if (0 < (int)pbStack16) {
          pbStack20 = pbStack16;
          while ((int)pbStack20 < 3) {
            abStack8[(int)pbStack20] = 0;
            pbStack20 = pbStack20 + 1;
          }
          iVar2 = (int)((uint)abStack8[0] & 0xfc) >> 2;
          uStack12 = (char)iVar2;
          if ((int)acStack104[iVar2] != (uint)*param_2) {
            return 0;
          }
          bStack11 = (char)(((uint)abStack8[0] & 3) << 4) +
                     (char)((int)((uint)abStack8[1] & 0xf0) >> 4);
          if ((int)acStack104[bStack11] != (uint)param_2[1]) {
            return (uint)param_2 & 0xffffff00;
          }
          bStack10 = (char)((int)((uint)abStack8[2] & 0xc0) >> 6) + (abStack8[1] & 0xf) * '\x04';
          if ((int)acStack104[bStack10] != (uint)param_2[2]) {
            return 0;
          }
          bStack9 = abStack8[2] & 0x3f;
          pbVar1 = param_2;
          if ((int)acStack104[abStack8[2] & 0x3f] != (uint)param_2[3]) {
            return (uint)param_2 & 0xffffff00;
          }
        }
        return CONCAT31((int3)((uint)pbVar1 >> 8),1);
      }
      abStack8[(int)pbStack16] = *param_1;
      pbStack16 = pbStack16 + 1;
      param_1 = param_1 + 1;
      pbVar1 = pbStack16;
    } while (pbStack16 != (byte *)0x3);
    iVar2 = (int)((uint)abStack8[0] & 0xfc) >> 2;
    uStack12 = (char)iVar2;
    if ((int)acStack104[iVar2] != (uint)*param_2) {
      return 0;
    }
    bStack11 = (char)(((uint)abStack8[0] & 3) << 4) + (char)((int)((uint)abStack8[1] & 0xf0) >> 4);
    if ((int)acStack104[bStack11] != (uint)param_2[1]) {
      return (uint)param_2 & 0xffffff00;
    }
    bStack10 = (char)((int)((uint)abStack8[2] & 0xc0) >> 6) + (abStack8[1] & 0xf) * '\x04';
    if ((int)acStack104[bStack10] != (uint)param_2[2]) {
      return 0;
    }
    bStack9 = abStack8[2] & 0x3f;
    if ((int)acStack104[abStack8[2] & 0x3f] != (uint)param_2[3]) break;
    pbStack16 = (byte *)0x0;
    pbVar1 = param_2;
  }
  return (uint)param_2 & 0xffffff00;
}



'''
